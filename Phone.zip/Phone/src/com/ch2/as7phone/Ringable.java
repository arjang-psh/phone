package com.ch2.as7phone;

public interface Ringable {
	abstract String ring();
	
	abstract String unlock();
}
